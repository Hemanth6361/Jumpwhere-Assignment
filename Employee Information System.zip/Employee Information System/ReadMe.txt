Download and Extract the provided source code zip file.

Open your Terminal/Command Prompt window.

Change the working directory to the extracted source code folder.
(Example : PS C:\Users\19052022\Desktop\Jumpwhere Project\Employee Information System> )

Run the following commands:
  pip install Django
  python manage.py migrate
  python manage.py runserver


Open a web browser and browse 
http://localhost:8000/ or http://127.0.0.1:8000/